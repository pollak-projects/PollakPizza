<template>
  <v-main>
    <router-view />
  </v-main>

  <AppFooter />
</template>

<script setup>
  //
</script>
