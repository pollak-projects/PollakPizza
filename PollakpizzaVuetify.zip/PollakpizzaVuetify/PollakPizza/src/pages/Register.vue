<template>
    <registerPage/>
</template>