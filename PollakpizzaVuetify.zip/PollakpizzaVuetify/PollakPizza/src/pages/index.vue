<template>
  <LoginPage/>
</template>

<script setup>
  //
</script>
